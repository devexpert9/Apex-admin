import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-eapps',
  templateUrl: './eapps.component.html',
  styleUrls: ['./eapps.component.scss']
})
export class EAPPSComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
